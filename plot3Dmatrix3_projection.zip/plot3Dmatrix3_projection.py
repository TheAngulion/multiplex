# plot 2D matrix

'''
by the incredible A.M. (andreas.moeglich@uni-bayreuth.de)
'''

import numpy as np
from matplotlib import pyplot as plt
from matplotlib import cm
from mpl_toolkits.mplot3d import Axes3D  # noqa: F401 unused import
import matplotlib
matplotlib.rcParams.update({'svg.fonttype': 'none'})
matplotlib.rcParams['grid.linewidth'] = .3

# this is the input file name and the z-axis limits for the two fluorescence channels
filename, zmin, zmax, zmin2, zmax2 = '11242023_multiplex2.txt', 0, 1, 0, .3

# these are the max. values for DsRed and YPet fluorescence
NORMALIZE_DSRED, NORMALIZE_YPET = 169078, 427755
# these are the calibration factors that convert Arduino units to light power
# additionally, can consider duty cycle here
ARDUINO_RED, ARDUINO_BLUE = .153, .209
cmap, cmap2 = cm.magma, cm.viridis

def applySettings(axis=None, zmin=0, zmax=1):
  if(axis != None):
    # put a few spaces for better alignment
    axis.set_ylabel('<BL> ($\mu$W cm$^{-2}$)   ')
    axis.set_xlabel('<RL> ($\mu$W cm$^{-2}$)  ')
    axis.set_xlabel('$\overline{RL}$ ($\mu$W cm$^{-2}$)')
    axis.zaxis.set_rotate_label(False)
    axis.set_zlabel('$F$ / $OD_{600}$ (a.u.)', rotation=94)
    #plt.title('$Ds$Red Expression (' + filename + ')')
    axis.w_xaxis.set_pane_color([1.0] * 4)
    axis.w_yaxis.set_pane_color([1.0] * 4)
    axis.w_zaxis.set_pane_color([0.8] * 4)
    axis.xaxis.set_ticks([0, 4, 8])
    axis.yaxis.set_ticks([0, 4, 8])
    zticks = [zmin, (zmin + zmax) / 2., zmax]
    axis.zaxis.set_ticks(zticks)
    zlabels = [str(i) for i in zticks]
    for i in zlabels:
      while(len(i) and (i.endswith('0') or i.endswith('.'))):
        i = i[:-1]
    axis.zaxis.set_ticklabels(zlabels)
    axis.xaxis.label.set_fontsize(8)
    axis.yaxis.label.set_fontsize(8)
    axis.zaxis.label.set_fontsize(8)
    axis.xaxis.labelpad = -8
    axis.yaxis.labelpad = -10
    axis.zaxis.labelpad = -8
    axis.zaxis._axinfo['juggled'] = (1, 2, 0)
    axis.set_position([0, 0, 1, 1])
    #
    ticks = axis.xaxis.get_major_ticks() + axis.yaxis.get_major_ticks() + axis.zaxis.get_major_ticks()
    xlabels, ylabels, zlabels = axis.get_xticklabels(), axis.get_yticklabels(), axis.get_zticklabels()
    ticklabels = xlabels + ylabels + zlabels
    for tick in ticks:
      tick.set_pad(-1)
    for tick in axis.yaxis.get_major_ticks():
      tick.set_pad(-4)
    for tick in axis.zaxis.get_major_ticks():
      tick.set_pad(-6)
    for label in ticklabels:
      label.set_fontname('Arial')
      label.set_fontsize(7)
    for label in xlabels:
      label.set_ha('center')
      label.set_va('baseline')
    for label in ylabels:
      label.set_va('baseline')
      label.set_ha('left')
    for label in zlabels:
      label.set_va('center')
      label.set_ha('right')

data = np.loadtxt(filename)
xv = data[:, 0] * ARDUINO_RED
yv = data[:, 1] * ARDUINO_BLUE
values = data[:, 2] / NORMALIZE_DSRED

# plot data
fig = plt.figure()
ax = fig.add_subplot(111, projection='3d')
surf = ax.plot_trisurf(xv, yv, values, cmap=cmap)
applySettings(axis=ax, zmin=zmin, zmax=zmax)
fig.set_facecolor('None')
fig.set_size_inches(1.7, 1.7, forward=True)
plt.draw()
usename = filename.split('.')[0] + '_DsRed.svg'
plt.savefig(usename, facecolor=None, egdecolor=None)


# plot data
values = data[:, 4] / NORMALIZE_YPET
fig2 = plt.figure()
ax2 = fig2.add_subplot(111, projection='3d')
surf = ax2.plot_trisurf(xv, yv, values, cmap=cmap2)
applySettings(axis=ax2, zmin=zmin2, zmax=zmax2)
fig2.set_facecolor('None')
fig2.set_size_inches(1.7, 1.7, forward=True)
plt.draw()
usename = filename.split('.')[0] + '_YPet.svg'
plt.savefig(usename, facecolor=None, egdecolor=None)

