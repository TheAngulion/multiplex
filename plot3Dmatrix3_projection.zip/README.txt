Python script for preparing surface plots for dual-color reporter-gene experiments
----------------------------------------------------------------------------------

by A.M. 2023 (andreas.moeglich@uni-bayreuth.de) and S.M. (stefanie.meier@uni-bayreuth.de)

1. System requirements
- Python 3, tested on several versions from 3.6 - 3.12
- several Python libraries (with the program version tested in parentheses): numpy (1.19.5), matplotlib (3.1.2)

2. Installation instructions
- copy to target directory
- place input data (.txt file) in the same directory

3. Demo
- run the script (as is): plot3Dmatrix3_projection.py
- opens input data: 11242023_multiplex2.txt
  (the columns are <software setting red light intensity> <software setting blue light intensity> <mean DsRed fluoresence> <s.d.> <mean YPet fluoresence> <s.d.>)
  (the software settings for the intensities are converted into actual light intensities within the script)

- outputs surface plot of DsRed fluorescence as a function of applied blue and red light intensities: 11242023_multiplex2_DsRed.svg
- outputs surface plot of YPet fluorescence as a function of applied blue and red light intensities: 11242023_multiplex2_YPet.svg

4. Instructions for use
- provide input text file in the same structure as the example file
- specify filename within script
- set maximum fluorescence values for DsRed and YPet to allow normalization (variables NORMALIZE_DSRED and NORMALIZE_YPET)
- set proportionality factor to convert software settings for blue and red light intensities to actual light powers (variables ARDUINO_RED and ARDUINO_BLUE)
- optionally, choose different color maps using the variables cmap and cmap2
- run script from command line or out of IDE